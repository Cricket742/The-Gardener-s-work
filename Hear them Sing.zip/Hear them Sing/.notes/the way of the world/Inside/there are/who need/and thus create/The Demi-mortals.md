There are many types of Demi-mortals. 

Every human likely has at least one demi-mortal connected to them. Most likely many more.

Guardians are created from the desire to protect the self or others.

They are limited in their ability to do so, but they are often credited with what some would call miracles. When something terrible is likely happen but does not, they tip the scales ever so slightly in favor of their charge.

Many guardians are created for their charges by parents or others around them at their charges' birth. 

This is similar to how monsters are made

Monsters are created from a primordial fear of things that aren't really a threat anymore. The dark, thunder, strange creatures, things like that.

Monsters are often created in a human's childhood, and even if they out grow their fears they still stay with them throughout their lives, similar to guardians.

Monsters and guardians both work under certain hierarchical structures created by older members of the respective factions.

The two factions however have years worth of bad blood, which is not great when a guardian and a monster fall in love.

Now let's talk about [[You]]