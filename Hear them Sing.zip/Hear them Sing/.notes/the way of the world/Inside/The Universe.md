The universe is dichotomous in some ways. Energy and entropy, darkness and light, making and unmaking all flow together as one.

The creatures that live in however are far from dichotomous.

Let us begin with [[The Immortals]]