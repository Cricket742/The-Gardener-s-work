You, like many mortals have a guardian and a monster. Their names are Daanriel and Timaethus. And as you might have gathered they have fallen in love.

My reason for contacting you has been to ask for your help. I have taken great measures to ensure that their relationship remains a secret while creating these messages for you.

I am but a sower of seeds. You as a mortal can help more than I ever could.

You have the power to make a place for them. A place where they can meet in safety.

So I ask of thee, check the templates folder, and open the template in there.

For tim and dan.