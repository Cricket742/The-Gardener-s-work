Life is a thing that defies all logic. To live is to change the world around you in a way it would not be without.

Immortals are the living beyond life. They do not live as all other life does. They exist as the nonliving exists. Mortals give the material meaning, and from that create immortals.

Immortals may have a lot of power but they still bend to the whim of mortals for their mere existence.

There are many types of mortals, some older than others, some more prominent than others. The immortals become almost inconsequential when mortals become strong enough.

As the they are stronger than ever now, let us continue to [[The Mortals]]