The most common mortals are humans. 

In a short amount of time they have become the most numerous of species of Earth. Because of this they have tipped the balance. In many ways, but the particular one I am speaking of is demi-mortals

These beings are created from the ideas of mortals, just as immortals are, but they are not nearly as vast. They come from something very unique to the modern human: the concept of the self.

Within the self they see forces beyond them and beyond the people that surround them. Luck, fate, and karma are some examples of these things. In nature these are merely the byproduct of life; the uncertain is present when there is no finite truth.

By observation they invent these forces as away to explain what cannot truly be explained.

These forces create [[The Demi-mortals]]. 