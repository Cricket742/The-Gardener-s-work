help these poor souls
https://letthemloveeachother.tumblr.com/